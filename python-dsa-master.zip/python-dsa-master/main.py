from Algorithms.Sorting.MergeSort import *

print(MergeSort([8,2,9,1,0,6,3,5]))